const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;

// Configuração do MySQL
const db = mysql.createConnection({
  host: '192.168.78.32',
  user: 'seraggi',
  password: '123',
  database: 'Sabha',
});

db.connect((err) => {
  if (err) {
    console.error('Erro ao conectar ao MySQL:', err.message);
  } else {
    console.log('Conectado ao MySQL');
  }
});

// Configuração do Express para lidar com JSON e formulários
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors()); // Middleware CORS para permitir solicitações de diferentes origens

// Rota para obter todos os usuários
app.get('/api/usuarios', (req, res) => {
  const query = 'SELECT * FROM usuario';

  db.query(query, (err, results) => {
    if (err) {
      console.error('Erro na consulta:', err.message);
      res.status(500).send('Erro interno do servidor');
    } else {
      res.json(results);
    }
  });
});

// Rota para criar um novo usuário
app.post('/api/usuarios', (req, res) => {
  const { nome, email } = req.body;
  const query = 'INSERT INTO usuario (nome, email) VALUES (?, ?)';

  db.query(query, [nome, email], (err, results) => {
    if (err) {
      console.error('Erro ao criar usuário:', err.message);
      res.status(500).send('Erro interno do servidor');
    } else {
      res.status(201).send('Usuário criado com sucesso');
    }
  });
});



// Rota para excluir um usuário por ID
app.delete('/api/usuarios/:id', (req, res) => {
  const userId = req.params.id;
  const query = 'DELETE FROM usuario WHERE id = ?';

  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('Erro ao excluir usuário:', err.message);
      res.status(500).send('Erro interno do servidor');
    } else {
      res.status(200).send('Usuário excluído com sucesso');
    }
  });
});


app.put('/api/usuarios/:id', (req, res) => {
  const userId = req.params.id;
  const { nome, email } = req.body;
  const query = 'UPDATE usuario SET nome = ?, email = ? WHERE id = ?';

  db.query(query, [nome, email, userId], (err, results) => {
    if (err) {
      console.error('Erro ao atualizar usuário:', err.message);
      res.status(500).send('Erro interno do servidor');
    } else {
      res.status(200).send('Usuário atualizado com sucesso');
    }
  });
});

app.get('/api/usuarios/:id', (req, res) => {
  const userId = req.params.id;
  const query = 'SELECT * FROM usuario WHERE id = ?';

  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('Erro na consulta:', err.message);
      res.status(500).send('Erro interno do servidor');
    } else {
      res.json(results[0]); // Retorna apenas o primeiro resultado (único usuário)
    }
  });
});




app.listen(port, () => {
  console.log(`Servidor está ouvindo na porta ${port}`);
});
